// Esperamos a que todo el contenido del HTML esté cargado
document.addEventListener('DOMContentLoaded', function() {

    // Seleccionamos los elementos del formulario que vamos a necesitar
    const form = document.getElementById('registro-form');
    const nombreInput = document.getElementById('nombre');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    // Seleccionamos los spans donde mostraremos los mensajes de error
    const errorNombre = document.getElementById('error-nombre');
    const errorEmail = document.getElementById('error-email');
    const errorPassword = document.getElementById('error-password');

    // Añadimos un "escuchador" al evento 'submit' del formulario
    form.addEventListener('submit', function(event) {
        
        // Prevenimos que el formulario se envíe automáticamente 
        event.preventDefault(); 

        let esValido = true; // Una variable para rastrear si todo es correcto

        // --- INICIO DE VALIDACIONES ---

        // 1. Limpiar errores anteriores para una nueva validación
        errorNombre.textContent = '';
        nombreInput.classList.remove('input-error');
        errorEmail.textContent = '';
        emailInput.classList.remove('input-error');
        errorPassword.textContent = '';
        passwordInput.classList.remove('input-error');

        // 2. Validación del nombre: no debe estar vacío
        if (nombreInput.value.trim() === '') {
            errorNombre.textContent = 'El nombre es obligatorio.'; // Mensaje de error claro
            nombreInput.classList.add('input-error');
            esValido = false;
        }

        // 3. Validación del email: formato válido
        // Usamos una expresión regular simple para validar el formato del email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailInput.value)) {
            errorEmail.textContent = 'Por favor, ingresa un correo electrónico válido.';
            emailInput.classList.add('input-error');
            esValido = false;
        }

        // 4. Validación de la contraseña: mínimo 8 caracteres
        if (passwordInput.value.length < 8) {
            errorPassword.textContent = 'La contraseña debe tener al menos 8 caracteres.';
            passwordInput.classList.add('input-error');
            esValido = false;
        }

        // Si todas las validaciones pasaron (esValido sigue siendo true)
        if (esValido) {
            alert('¡Formulario enviado con éxito!');
            // En una aplicación real, aquí se enviarían los datos a un servidor.
            // Para este ejercicio, podemos simplemente limpiar el formulario.
            form.reset(); 
        }
    });
});